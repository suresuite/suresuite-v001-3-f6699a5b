# SCSIM — supply chain simulation library and stress-test framework.
# Copyright (c) 2023-2026 Phu Nguyen. All rights reserved until the open-access
# release; see scsim/NOTICE.md for licensing, funding and citation.
# Developed in part within the ACCURATE project (Horizon Europe, GA 101138269).

"""P-P.1 inventory_control — BUILT_IN buffer (Part IV §4.1). ✅ min_max.

Context: the everyday replenishment rule — the baseline shock absorber every
chain already has; quantifying it prevents over-buying dedicated resilience.

Variants: min-max (ERP discrete manufacturing — the case company),
base-stock (high-value/low-volume), (R,Q) (stable flows), periodic
(consolidated cadence).

Mechanics (Eqs. 2–6): levels at PH-70, release at PH-80 — order
max(S_m − position, MOQ) when position < s_m, on the material's primary
(min-cost) supplier link.
"""
from __future__ import annotations

from typing import ClassVar, Literal, Optional

import logging

import numpy as np
from pydantic import Field, field_validator, model_validator

from scsim.core.context import SimContext
from scsim.core.phases import (
    INVENTORY_LEVELS,
    MATERIAL_DEMAND,
    PURCHASE_ORDERS,
    ST_ON_HAND,
    ST_PIPELINE,
    ST_QUEUE,
    Hook,
    PhaseId,
)
from scsim.entities.enums import (
    ConstraintTag,
    FulfillmentMode,
    PolicyStatus,
    Stage,
    StrategyClass,
    TransportMode,
)
from scsim.entities.network import Network
from scsim.entities.scenario import Scenario
from scsim.policies.base import (
    DataRequirement,
    FeasibilityIssue,
    FeasibilityResult,
    ModeStrip,
    PolicyParams,
    PolicyPlugin,
)
from scsim.policies.registry import register_plugin

_log = logging.getLogger(__name__)


def _primary_link_lts(net: Network) -> dict[str, int]:
    """Effective primary-link lead time per material id, mirroring
    CompiledModel's (cost, lt, supplier) primary selection and edge
    lead-time folding — kept in lockstep by a drift test."""
    lane_extra: dict[str, int] = {}
    for lane in sorted(net.lanes, key=lambda l: (l.mode != TransportMode.DEFAULT, l.id)):
        lane_extra.setdefault(lane.supplier_id, int(lane.lead_time_weeks))
    out: dict[str, int] = {}
    for link in sorted(net.supplier_links,
                       key=lambda l: (l.cost, l.lead_time_weeks, l.supplier_id)):
        out.setdefault(link.material_id,
                       int(link.lead_time_weeks) + lane_extra.get(link.supplier_id, 0))
    return out


class MaterialInventoryOverride(PolicyParams):
    """Per-material replenishment override (P-P.1, §II.3): the supplier grid's
    row-level adjustments. Every field is optional — an absent field keeps the
    project-default behavior (the Eqs. 2–3 formula levels), so an override row
    never silently replaces a formula it does not name."""

    policy_type: Optional[Literal["min_max", "base_stock", "rop_q", "periodic"]] = Field(
        None, json_schema_extra={"unit": "enum", "scope": "M",
                                 "notes": "Row-level policy type; absent → project default."},
    )
    rop_q_quantity: Optional[float] = Field(
        None, gt=0,
        json_schema_extra={"unit": "units", "scope": "M", "notes": "Fixed (R,Q) lot for this material."},
    )
    coverage_weeks: Optional[float] = Field(
        None, ge=0, le=26,
        json_schema_extra={"unit": "weeks", "scope": "M",
                           "notes": "Fixed κ for this material (all modes); absent → the strip."},
    )
    reorder_point: Optional[float] = Field(
        None, ge=0,
        json_schema_extra={"unit": "units", "scope": "M",
                           "notes": "Absolute s (R for rop_q) replacing E[D]·T_s for this material."},
    )
    order_up_to: Optional[float] = Field(
        None, gt=0,
        json_schema_extra={"unit": "units", "scope": "M",
                           "notes": "Absolute S replacing E[D]·(T_s+κ) for this material."},
    )

    @model_validator(mode="after")
    def _levels_ordered(self) -> "MaterialInventoryOverride":
        if (self.reorder_point is not None and self.order_up_to is not None
                and self.order_up_to <= self.reorder_point):
            raise ValueError("order_up_to must exceed reorder_point")
        return self


class InventoryControlParams(PolicyParams):
    policy_type: Literal["min_max", "base_stock", "rop_q", "periodic"] = Field(
        "min_max",
        json_schema_extra={"unit": "enum", "scope": "M", "notes": "min_max ✅ (manuscript)."},
    )
    basis: Literal["days_of_supply", "forward_visible"] = Field(
        "days_of_supply",
        json_schema_extra={
            "unit": "enum", "scope": "G/M",
            "notes": "Policy Basis (§II.4): days_of_supply sizes levels from the stationary "
                     "mean (s = E[D_m]·T_s); forward_visible sums the committed forward "
                     "order book over the coverage window (WSC-2026 MTO) — requires the "
                     "P-C.6 forward_visibility customer policy.",
        },
    )
    coverage_weeks: ModeStrip = Field(
        default_factory=lambda: ModeStrip(nominal=8, alert=10, crisis=12),
        json_schema_extra={
            "unit": "weeks", "scope": "G/M", "range": "[0, 26]",
            "notes": "κ — order-up-to cover beyond lead time. Strip 8/10/12.",
        },
    )
    review_cadence_weeks: Literal[1, 2, 4] = Field(
        1, json_schema_extra={"unit": "weeks", "scope": "G"},
    )
    rop_q_quantity: Optional[float] = Field(
        None, gt=0,
        json_schema_extra={"unit": "units", "scope": "M", "notes": "Fixed (R,Q) lot; ≥ MOQ enforced."},
    )
    periodic_review_weeks: int = Field(
        4, ge=1, le=13, json_schema_extra={"unit": "weeks", "scope": "G"},
    )
    material_overrides: dict[str, MaterialInventoryOverride] = Field(
        default_factory=dict,
        json_schema_extra={
            "unit": "map", "scope": "M",
            "notes": "material_id → row-level override from the supplier grid "
                     "(§II.3). Unknown material ids are ignored at runtime.",
        },
    )

    @field_validator("coverage_weeks")
    @classmethod
    def _kappa_range(cls, v: ModeStrip) -> ModeStrip:
        for mode in ("nominal", "alert", "crisis"):
            k = getattr(v, mode)
            if not (0 <= k <= 26):
                raise ValueError(f"coverage_weeks.{mode} must be in [0, 26]")
        return v

    @model_validator(mode="after")
    def _forward_needs_integral_kappa(self) -> "InventoryControlParams":
        if self.basis == "forward_visible":
            for mode in ("nominal", "alert", "crisis"):
                k = getattr(self.coverage_weeks, mode)
                if k != int(k):
                    raise ValueError(
                        f"basis='forward_visible' sums whole forward weeks: "
                        f"coverage_weeks.{mode} must be integral, got {k}"
                    )
        return self


@register_plugin
class InventoryControl(PolicyPlugin):
    id: ClassVar[str] = "inventory_control"
    catalog_ref: ClassVar[str] = "P-P.1"
    stage: ClassVar[Stage] = Stage.PLANT
    strategy_class: ClassVar[StrategyClass] = StrategyClass.BUILT_IN
    constraint_targeted: ClassVar[ConstraintTag] = ConstraintTag.MATERIAL_AVAILABILITY
    requires_predeployment: ClassVar[bool] = False
    status: ClassVar[PolicyStatus] = PolicyStatus.IMPLEMENTED
    summary: ClassVar[str] = (
        "Everyday replenishment rule (min-max / base-stock / (R,Q) / periodic). The baseline "
        "shock absorber every chain already has; quantifying it prevents over-buying "
        "dedicated resilience."
    )
    Params: ClassVar[type[PolicyParams]] = InventoryControlParams
    data_requirements: ClassVar[tuple[DataRequirement, ...]] = (
        DataRequirement(
            field="materials.moq", level="defaulted",
            reason="Minimum order quantity rounds up PH-80 order releases.",
            fallback="0 (no minimum)",
        ),
        DataRequirement(
            field="materials.holding_cost_pct", level="defaulted",
            reason="Holding cost rate prices the inventory this policy carries.",
            fallback="policy inventory.holding_cost_pct, then 20%",
        ),
    )

    @property
    def hooks(self) -> list[Hook]:
        return [
            Hook(
                phase=PhaseId.PH70, priority=50,
                reads={MATERIAL_DEMAND},
                writes={INVENTORY_LEVELS},
            ),
            Hook(
                phase=PhaseId.PH80, priority=50,
                reads={INVENTORY_LEVELS, ST_ON_HAND, ST_PIPELINE, ST_QUEUE},
                writes={PURCHASE_ORDERS},
            ),
        ]

    # ------------------------------------------------------------ feasibility

    def feasibility(self, scenario: Scenario) -> FeasibilityResult:
        p: InventoryControlParams = self.params
        if p.basis != "forward_visible":
            return FeasibilityResult.ok()
        # §II.4 two-stage contract: the forward basis is selectable only when
        # a customer policy provides τ* ≥ T_s + κ, and only for MTO worlds.
        fv = scenario.policies.get("forward_visibility")
        if fv is None:
            return FeasibilityResult(False, (FeasibilityIssue(
                "error", "forward_basis_needs_visibility",
                "basis='forward_visible' requires the forward_visibility customer policy "
                "(P-C.6): the plant can only read a forward order book a customer commits",
            ),))
        mts = [pr.id for pr in scenario.network.products
               if pr.fulfillment_mode == FulfillmentMode.MTS]
        if mts:
            return FeasibilityResult(False, (FeasibilityIssue(
                "error", "forward_basis_is_mto_only",
                f"basis='forward_visible' is MTO-only (§II.4): MTS products plan material "
                f"demand from the forecast, not the committed book — found MTS: {mts[:5]}",
            ),))
        tau = fv.get("visibility_horizon") or scenario.settings.visibility_horizon
        max_lt = max(_primary_link_lts(scenario.network).values(), default=0)
        kappa_crisis = int(p.coverage_weeks.crisis)
        if max_lt + kappa_crisis > tau:
            return FeasibilityResult(False, (FeasibilityIssue(
                "error", "coverage_beyond_visibility",
                f"forward windows must fit the visible book (T_s + κ ≤ τ*, §II.4): "
                f"max primary lead time {max_lt}w + crisis κ {kappa_crisis}w exceeds "
                f"τ* = {tau}w",
            ),))
        return FeasibilityResult.ok()

    # ---------------------------------------------------------------- runtime

    def _kappa(self, ctx: SimContext) -> float:
        strip: ModeStrip = self.params.coverage_weeks
        return strip.crisis if ctx.events_visible() else strip.nominal

    _TYPE_CODE = {"min_max": 0, "base_stock": 1, "rop_q": 2, "periodic": 3}

    def _override_arrays(
        self, m,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
        """Per-material vectors from `material_overrides`: (type_code, Q, κ,
        absolute s, absolute S). NaN means "no override" for the float arrays;
        unknown material ids are skipped (the mapping already filtered them)."""
        p: InventoryControlParams = self.params
        n = m.n_mats
        type_code = np.full(n, self._TYPE_CODE[p.policy_type], dtype=int)
        q = np.full(n, p.rop_q_quantity if p.rop_q_quantity is not None else np.nan)
        kappa = np.full(n, np.nan)
        s_abs = np.full(n, np.nan)
        S_abs = np.full(n, np.nan)
        for mid, ov in p.material_overrides.items():
            i = m.mat_index.get(mid)
            if i is None:
                continue
            if ov.policy_type is not None:
                type_code[i] = self._TYPE_CODE[ov.policy_type]
            if ov.rop_q_quantity is not None:
                q[i] = ov.rop_q_quantity
            if ov.coverage_weeks is not None:
                kappa[i] = ov.coverage_weeks
            if ov.reorder_point is not None:
                s_abs[i] = ov.reorder_point
            if ov.order_up_to is not None:
                S_abs[i] = ov.order_up_to
        return type_code, q, kappa, s_abs, S_abs

    def on_phase(self, phase: PhaseId, ctx: SimContext) -> None:
        if phase == PhaseId.PH70:
            self._set_levels(ctx)
        elif phase == PhaseId.PH80:
            self._release(ctx)

    def _set_levels(self, ctx: SimContext) -> None:
        m = ctx.model
        kappa = self._kappa(ctx)
        _types, _q, k_ov, s_abs, S_abs = self._override_arrays(m)
        kappa_vec = np.where(np.isnan(k_ov), float(kappa), k_ov)

        # κ diagnostics (9bf05df). DEBUG-level, not print(): PH70 runs every
        # simulated week of every replication, in the worker and the browser.
        if _log.isEnabledFor(logging.DEBUG):
            _log.debug("kappa (strip value): %s", kappa)
            _log.debug("k_ov (per-mat override): %s", k_ov)
            _log.debug("kappa_vec (effective): %s", kappa_vec)

        if self.params.basis == "forward_visible":
            # §II.4 Forward-visible schedule (WSC-2026 MTO), inclusive windows:
            # s_m[t] = Σ_{τ=t}^{t+T_s} D̂_m[τ]; S_m[t] = Σ_{τ=t}^{t+T_s+κ} D̂_m[τ].
            # cover_weeks accepts an (n_mats,) array, so per-material κ folds in.
            lt = m.link_lt[m.primary_link]
            t = ctx.week
            s = ctx.forward_material_demand(t, lt)
            S = ctx.forward_material_demand(t, lt + kappa_vec.astype(int))
        else:
            # Eqs. 2–3: s_m = E[D_m]·T_s ; S_m = E[D_m]·(T_s + κ). P-P.3 adds SS after us.
            exp_d = ctx.material_demand
            lt = m.link_lt[m.primary_link].astype(float)
            s = exp_d * lt
            S = exp_d * (lt + kappa_vec)
        # Absolute row-level levels (supplier grid) replace the formula where
        # present; S is kept ≥ s so a lone absolute s cannot invert the band
        # (both-set inversions are refused at validation).
        has_s = ~np.isnan(s_abs)
        has_S = ~np.isnan(S_abs)
        if has_s.any():
            s = np.where(has_s, s_abs, s)
        if has_S.any():
            S = np.where(has_S, S_abs, S)
        S = np.maximum(S, s)
        ctx.write_levels(s, S)

    def _release(self, ctx: SimContext) -> None:
        m = ctx.model
        p: InventoryControlParams = self.params
        position = ctx.on_hand + ctx.pipeline_on_order()
        orders_mat = np.zeros(m.n_mats)
        moq = m.link_moq[m.primary_link]
        type_code, qv, _k, _s, _S = self._override_arrays(m)
        short = position < ctx.level_s
        deficit = ctx.level_S - position

        mm = type_code == self._TYPE_CODE["min_max"]
        if ctx.week % p.review_cadence_weeks == 0:
            sel = mm & short
            orders_mat[sel] = np.maximum(deficit[sel], moq[sel])

        bs = (type_code == self._TYPE_CODE["base_stock"]) & (deficit > 1e-12)
        orders_mat[bs] = np.maximum(deficit[bs], moq[bs])

        rq = (type_code == self._TYPE_CODE["rop_q"]) & short
        # DECLARED fallback (T2): an (R,Q) material with no Q orders up to S —
        # the min_max lot — never a silent zero order. The mapping states this
        # substitution as a MappingWarning at dispatch.
        q_sel = qv[rq]
        orders_mat[rq] = np.maximum(np.where(np.isnan(q_sel), deficit[rq], q_sel), moq[rq])

        pr = type_code == self._TYPE_CODE["periodic"]
        if ctx.week % p.periodic_review_weeks == 0:
            sel = pr & (deficit > 1e-12)
            orders_mat[sel] = np.maximum(deficit[sel], moq[sel])

        orders = np.zeros(m.n_links)
        nonzero = orders_mat > 0
        orders[m.primary_link[nonzero]] = orders_mat[nonzero]
        ctx.write_purchase_orders(orders)
